import os
import secrets

class Config:
    SECRET_KEY = secrets.token_hex(16)
    SQLALCHEMY_DATABASE_URI = 'sqlite:///onboarding.db'
    # Mail configurations
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'sandbox.smtp.mailtrap.io')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 2525))
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME', '7b6045193c59b1')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD', 'b91a5e67598928')
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS', 'True').lower() in ('true', '1', 't')
    MAIL_USE_SSL = os.environ.get('MAIL_USE_SSL', 'False').lower() in ('true', '1', 't')
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER', 'test@vacobinary.in')
    # Jira configurations
    JIRA_URL = os.environ.get('JIRA_URL', "https://vacobinary.atlassian.net")
    JIRA_EMAIL = os.environ.get('JIRA_EMAIL', "akhil.bhatnagar@vacobinary.in")
    JIRA_API_TOKEN = os.environ.get('JIRA_API_TOKEN',
                                    "ATATT3xFfGF07yC3qGrQPW_KYRzZABG_A4kQw9tGjBtFQz6udOApe3hX_YfF-MwGrTRiS-tC-SPbfldkWpcKujFO5RNpQwmBq8fRxuSX_yFtstZErbQEGQC7sLNACbMsz4rqaIhS-j77oZOCto-0hv3WjHEnN1vtUTVis5iXW2ZYSQR37z2XhsI=9BFEB3D2")
    JIRA_PROJECT_KEY = os.environ.get('JIRA_PROJECT_KEY', "AO")
    # Email recipients for specific teams (adjust these to your actual team emails)
    DEV_EMAIL_RECIPIENT = os.environ.get('DEV_EMAIL_RECIPIENT', 'dev-auto-onboard@vacobinary.in')
    IT_EMAIL_RECIPIENT = "it@company.com"
    HR_EMAIL_RECIPIENT = "hr@company.com"
    TRANSPORT_EMAIL_RECIPIENT = "transport@company.com"
    SECURITY_EMAIL_RECIPIENT = "security@company.com"
    ADMIN_EMAIL_RECIPIENT = "admin@company.com"
